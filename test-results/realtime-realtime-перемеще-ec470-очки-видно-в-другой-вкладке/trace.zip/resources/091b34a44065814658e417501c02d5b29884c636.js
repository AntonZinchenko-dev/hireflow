(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_@dnd-kit_core_dist_core_esm_0i-bf15.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0q79z23._.js","static/chunks/node_modules_react-hook-form_dist_index_esm_mjs_0b0kr13._.js","static/chunks/node_modules_zod_v4_1ujpcun._.js","static/chunks/node_modules_@base-ui_react_1z32cv8._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_1vqrmkg._.js","static/chunks/node_modules_13rxd4w._.js","static/chunks/src_0zovc_z._.js"],
    source: "dynamic"
});
